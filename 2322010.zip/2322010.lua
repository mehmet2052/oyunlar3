-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2322010)
addappid(2322011, 1, "78758c85a2a8b04770fb4fe430ac7a215a959b72e496d94f6a0ec5ac38066f49")
setManifestid(2322011, "5866573615378835835", 0)